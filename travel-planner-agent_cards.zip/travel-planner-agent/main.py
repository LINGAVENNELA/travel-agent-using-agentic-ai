# # import os
# # from dotenv import load_dotenv

# # # Load environment variables
# # load_dotenv()

# # from agent.graph import app
# # from utils.formatter import format_itinerary

# # def main():
# #     print("Welcome to the Travel Planner Agent!")
    
# #     # Check for API key
# #     if not os.getenv("GOOGLE_API_KEY"):
# #         print("Warning: GOOGLE_API_KEY not found in environment variables. The agent might fail or run in mock mode.")
    
# #     user_input = input("Where would you like to go? (e.g., 'Plan a 3-day trip to Paris'): ")
    
# #     if not user_input:
# #         print("Please provide a request.")
# #         return

# #     print(f"\nProcessing request: {user_input}...\n")
    
# #     # Initial state
# #     initial_state = {"user_request": user_input, "messages": []}
    
# #     # Run the graph
# #     try:
# #         result = app.invoke(initial_state)
        
# #         final_itinerary = result.get("final_itinerary")
# #         validation_error = result.get("validation_error")
        
# #         if validation_error:
# #             print(f"Error: {validation_error}")
# #             if final_itinerary: # Show what we have anyway
# #                  print(format_itinerary(final_itinerary))
# #         elif final_itinerary:
# #             print(format_itinerary(final_itinerary))
# #         else:
# #             print("No itinerary generated.")
            
# #     except Exception as e:
# #         print(f"An error occurred: {e}")

# # if __name__ == "__main__":
# #     main()


# import os
# from dotenv import load_dotenv

# load_dotenv()

# from utils.formatter import format_itinerary


# def run_travel_agent(user_input: str):
#     """
#     This function is used by Streamlit.
#     It runs the LangGraph app and returns the itinerary text.
#     """

#     # ⛔ lazy import fixes circular import
#     from agent.graph import app

#     # initial_state = {"user_request": user_input, "messages": []}
#     initial_state = {
#     "user_request": user_input,
#     "messages": [],
#     "iteration_count": 1}


#     try:
#         result = app.invoke(initial_state)

#         final_itinerary = result.get("final_itinerary")
#         validation_error = result.get("validation_error")

#         if validation_error:
#             return f"Error: {validation_error}\n\n{format_itinerary(final_itinerary) if final_itinerary else ''}"

#         if final_itinerary:
#             return format_itinerary(final_itinerary)

#         return "No itinerary generated."

#     except Exception as e:
#         return f"An error occurred: {e}"


# # ---------------- CLI MODE (optional, still works) ---------------- #
# def main():
#     print("Welcome to the Travel Planner Agent!")

#     if not os.getenv("GOOGLE_API_KEY"):
#         print("Warning: GOOGLE_API_KEY not found in environment variables.")

#     user_input = input("Where would you like to go? (e.g., 'Plan a 3-day trip to Paris'): ")

#     if not user_input:
#         print("Please provide a request.")
#         return

#     print(f"\nProcessing request: {user_input}...\n")

#     result = run_travel_agent(user_input)
#     print(result)


# if __name__ == "__main__":
#     main()


import os
from dotenv import load_dotenv

load_dotenv()

def run_travel_agent(user_input: str):
    from agent.graph import app

    initial_state = {
        "user_request": user_input
    }

    try:
        result = app.invoke(initial_state)

        if "itinerary" in result:
            return result["itinerary"]

        return "No itinerary generated."
    except Exception as e:
        return f"Error: {e}"
