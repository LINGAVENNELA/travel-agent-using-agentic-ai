from typing import List, TypedDict, Optional
from pydantic import BaseModel, Field

class Activity(BaseModel):
    title: str = Field(description="Name of the activity")
    cost: float = Field(description="Estimated cost in USD")
    description: str = Field(description="Brief description")
    time_slot: str = Field(description="e.g., Morning, Afternoon, Evening")

class DayPlan(BaseModel):
    day_number: int
    activities: List[Activity]

class TripItinerary(BaseModel):
    total_estimated_cost: float
    daily_plans: List[DayPlan]

class PlanState(TypedDict):
    budget: float
    city: str
    days: int
    interests: str
    itinerary: Optional[TripItinerary]
    error_message: Optional[str]
    iteration_count: int