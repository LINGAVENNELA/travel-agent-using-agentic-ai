# # import os
# # from dotenv import load_dotenv

# # load_dotenv()

# # from agent.graph import graph
# # from utils.formatter import format_itinerary

# # def main():
# #     print("Welcome to the Travel Planner Agent!")

# #     if not os.getenv("GOOGLE_API_KEY"):
# #         print(
# #             "Warning: GOOGLE_API_KEY not found in environment variables. "
# #             "The agent might fail or run in mock mode."
# #         )

# #     user_input = input(
# #         "Where would you like to go? (e.g., 'Plan a 3-day trip to Paris'): "
# #     )

# #     if not user_input:
# #         print("Please provide a request.")
# #         return

# #     print(f"\nProcessing request: {user_input}...\n")

# #     initial_state = {
# #         "user_request": user_input,
# #         "messages": []
# #     }

# #     try:
# #         result = graph.invoke(initial_state)

# #         final_itinerary = result.get("final_itinerary")
# #         validation_error = result.get("validation_error")

# #         if validation_error:
# #             print(f"Error: {validation_error}")

# #         if final_itinerary:
# #             print(format_itinerary(final_itinerary))
# #         else:
# #             print("No itinerary generated.")

# #     except Exception as e:
# #         print(f"An error occurred: {e}")

# # if __name__ == "__main__":
# #     main()


# from langgraph.graph import StateGraph
# # from agent.nodes import planner_node, validator_node, replanner_node, presenter_node
# from agent.nodes import planner_node, validator_node, presenter_node



# # -------- DEFINE GRAPH STATE -------
# def graph_state(state):
#     return state


# # -------- BUILD GRAPH ------------
# graph = StateGraph(graph_state)

# graph.add_node("planner", planner_node)
# graph.add_node("validator", validator_node)
# # graph.add_node("replanner", replanner_node)
# graph.add_node("presenter", presenter_node)

# graph.set_entry_point("planner")

# graph.add_edge("planner", "validator")
# # graph.add_edge("validator", "replanner")   # if fails goes to replanner
# # graph.add_edge("replanner", "validator")   # loop back again
# graph.add_edge("validator", "presenter")   # success goes to presenter

# # -------- COMPILE APP ------------
# app = graph.compile()


from langgraph.graph import StateGraph
from agent.nodes import planner_node, validator_node, presenter_node

graph = StateGraph(dict)

graph.add_node("planner", planner_node)
graph.add_node("validator", validator_node)
graph.add_node("presenter", presenter_node)

graph.set_entry_point("planner")

graph.add_edge("planner", "validator")
graph.add_edge("validator", "presenter")

app = graph.compile()
