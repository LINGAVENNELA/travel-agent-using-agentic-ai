# import os
# from dotenv import load_dotenv
# from langchain_google_genai import ChatGoogleGenerativeAI
# from .state import PlanState, TripItinerary

# load_dotenv()

# def get_llm():
#     api_key = os.getenv("GOOGLE_API_KEY")
#     if not api_key:
#         raise ValueError("GOOGLE_API_KEY not found in environment.")
    
#     # Updated to gemini-2.5-flash for 2025 stability
#     return ChatGoogleGenerativeAI(
#         model="gemini-2.5-flash", 
#         google_api_key=api_key
#     ).with_structured_output(TripItinerary)

# def planner_node(state: PlanState):
#     print(f"--- 🔄 PLANNING ITERATION {state['iteration_count'] + 1} ---")
    
#     llm = get_llm()
#     feedback = f"\nPREVIOUS ERROR: {state['error_message']}" if state["error_message"] else ""

#     prompt = (
#         f"Plan a {state['days']}-day trip to {state['city']} for someone interested in {state['interests']}. "
#         f"Budget: ${state['budget']}. Ensure the sum of activity costs is exactly within budget. "
#         f"{feedback}"
#     )
#     count = state.get("iteration_count", 1)

#     itinerary = llm.invoke(prompt)
#     return {
#         "itinerary": itinerary,
#         "iteration_count": state["iteration_count"] + 1,
#         "error_message": None # Reset error for validator to re-check
#     }

# def validator_node(state: PlanState):
#     itin = state["itinerary"]
#     actual_sum = sum(act.cost for day in itin.daily_plans for act in day.activities)
    
#     print(f"--- ⚖️ VALIDATING: Total Cost ${actual_sum} ---")

#     if actual_sum > state["budget"]:
#         err = f"Over budget! ${actual_sum} > ${state['budget']}."
#         return {"error_message": err}
    
#     return {"error_message": "SUCCESS"}

# def presenter_node(state):
#     # Assumes itinerary already exists in state
#     return state


import os
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

def get_llm():
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise ValueError("GOOGLE_API_KEY missing")

    return ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        google_api_key=api_key
    )

def planner_node(state):
    llm = get_llm()

    prompt = (
        f"You are an expert travel planner.\n"
        f"User Request:\n{state['user_request']}\n\n"
        f"Create:\n"
        f"- Day-wise plan\n"
        f"- Activities\n"
        f"- Costs\n"
        f"- Short descriptions\n"
        f"Respond clearly and neatly."
    )

    response = llm.invoke(prompt).content

    return {"itinerary": response}

def validator_node(state):
    # Always approve for now
    return state

def presenter_node(state):
    return state
