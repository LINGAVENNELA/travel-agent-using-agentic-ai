
import streamlit as st
from main import run_travel_agent
import re

st.set_page_config(page_title="🧳 AI Travel Planner", layout="wide")

st.title("✨ AI Travel Planner")
st.caption("Day-wise itinerary displayed as cards")

from_city = st.text_input("From City")
to_city = st.text_input("To City")
start_date = st.date_input("Start Date")
end_date = st.date_input("End Date")
budget = st.number_input("Budget (₹)", min_value=1000, step=500)

preferences = st.multiselect(
    "Preferences",
    ["Adventure", "Relaxation", "Food", "Shopping", "Nature", "Culture"]
)

if st.button("🧠 Generate Itinerary"):
    with st.spinner("Planning your trip..."):
        prompt = (
            f"Plan a detailed day-wise trip from {from_city} to {to_city} "
            f"from {start_date} to {end_date} with budget ₹{budget}. "
        )
        if preferences:
            prompt += f"Preferences: {', '.join(preferences)}."

        itinerary_text = run_travel_agent(prompt)

    st.subheader("🗓️ Your Itinerary")

    # Split itinerary into days
    days = re.split(r"Day\s*\d+[:\-]?", itinerary_text)

    for i, content in enumerate(days):
        if content.strip():
            with st.container():
                st.markdown(
                    f'''
                    <div style="
                        background:#ffffff;
                        padding:25px;
                        border-radius:20px;
                        box-shadow:0 15px 35px rgba(0,0,0,0.1);
                        margin-bottom:25px;">
                        <h3>Day {i}</h3>
                        <p>{content}</p>
                    </div>
                    ''',
                    unsafe_allow_html=True
                )
