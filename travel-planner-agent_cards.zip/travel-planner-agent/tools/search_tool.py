def search_flights(origin: str, destination: str, date: str) -> str:
    """
    Mock function to search for flights.
    In a real application, this would call an API like Tavily or Google Flights.
    """
    return f"Found mock flights from {origin} to {destination} on {date}: Flight A ($300), Flight B ($450)."

def search_hotels(destination: str, check_in: str) -> str:
    """
    Mock function to search for hotels.
    """
    return f"Found mock hotels in {destination} for check-in {check_in}: Hotel X ($100/night), Hotel Y ($200/night)."

def search_activities(destination: str) -> str:
    """
    Mock function to search for activities.
    """
    return f"Top activities in {destination}: Museum visit, City Park, Local Food Tour."
