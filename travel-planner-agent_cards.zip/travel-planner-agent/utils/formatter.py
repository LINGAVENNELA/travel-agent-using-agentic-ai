def format_itinerary(itinerary: str) -> str:
    """
    Formats the itinerary for display.
    """
    if not itinerary:
        return "No itinerary generated."
        
    border = "=" * 50
    return f"\n{border}\n       TRAVEL ITINERARY       \n{border}\n\n{itinerary}\n\n{border}"
